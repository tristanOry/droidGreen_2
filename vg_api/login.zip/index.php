<html>
<body>
<form method="post" action="login.php">
<input name="mail">
<input name="pass">
<button type="submit">b</button>

</form>